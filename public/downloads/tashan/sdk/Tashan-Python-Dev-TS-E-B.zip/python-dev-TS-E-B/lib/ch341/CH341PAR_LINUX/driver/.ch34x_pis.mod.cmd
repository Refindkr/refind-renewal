savedcmd_ch34x_pis.mod := printf '%s\n'   ch34x_pis.o | awk '!x[$$0]++ { print("./"$$0) }' > ch34x_pis.mod
