#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xde338d9a, "_raw_spin_unlock" },
	{ 0xc3f320b4, "usb_free_coherent" },
	{ 0x4073d0de, "up" },
	{ 0xe8213e80, "_printk" },
	{ 0xadb55ac9, "usb_register_driver" },
	{ 0xf2f79e52, "fasync_helper" },
	{ 0xe54e0a6b, "__fortify_panic" },
	{ 0xa53f4e29, "memcpy" },
	{ 0xe1e1f979, "_raw_spin_lock_irqsave" },
	{ 0x562e3aaa, "__kfifo_in" },
	{ 0x81a1a811, "_raw_spin_unlock_irqrestore" },
	{ 0x16ab4215, "__wake_up" },
	{ 0xa6c3b74d, "ktime_get_mono_fast_ns" },
	{ 0xbe011736, "__dynamic_dev_dbg" },
	{ 0x9d33f583, "kill_fasync" },
	{ 0xa8f96c6e, "usb_deregister" },
	{ 0x12694399, "down_interruptible" },
	{ 0xde338d9a, "_raw_spin_lock_irq" },
	{ 0xde338d9a, "_raw_spin_unlock_irq" },
	{ 0x3fdc3369, "usb_alloc_urb" },
	{ 0x092a35a2, "_copy_from_user" },
	{ 0x0c8e9a2d, "usb_free_urb" },
	{ 0x37688b23, "usb_alloc_coherent" },
	{ 0x95c7e581, "usb_anchor_urb" },
	{ 0x0c8e9a2d, "usb_unanchor_urb" },
	{ 0x1094eaab, "usb_wait_anchor_empty_timeout" },
	{ 0x0c8e9a2d, "usb_kill_urb" },
	{ 0x8dc67ef7, "usb_kill_anchored_urbs" },
	{ 0xe4de56b4, "__ubsan_handle_load_invalid_value" },
	{ 0x9d783e76, "usb_find_interface" },
	{ 0xf76bbc40, "usb_autopm_get_interface" },
	{ 0x2520ea93, "refcount_warn_saturate" },
	{ 0x7851be11, "__get_user_1" },
	{ 0x6c00f410, "usb_control_msg" },
	{ 0x7851be11, "__get_user_4" },
	{ 0xd272d446, "__put_user_4" },
	{ 0x208da9f5, "usb_autopm_put_interface" },
	{ 0xd272d446, "__put_user_1" },
	{ 0xd1ea1c88, "__kfifo_out" },
	{ 0x7851be11, "__SCT__might_resched" },
	{ 0x7a5ffe84, "init_wait_entry" },
	{ 0x0db8d68d, "prepare_to_wait_event" },
	{ 0x6ac784f4, "schedule_timeout" },
	{ 0xc87f4bab, "finish_wait" },
	{ 0xa31fd687, "usb_put_dev" },
	{ 0x283bce08, "__kfifo_free" },
	{ 0x5403c125, "__init_waitqueue_head" },
	{ 0x37602407, "usb_get_dev" },
	{ 0xc1e6c71e, "__mutex_init" },
	{ 0x3d212d3d, "usb_register_dev" },
	{ 0xb3d1d601, "__kfifo_alloc" },
	{ 0x9b1de7cb, "_dev_info" },
	{ 0x887666e1, "usb_deregister_dev" },
	{ 0xd272d446, "__fentry__" },
	{ 0xd272d446, "__x86_return_thunk" },
	{ 0xf46d5bf3, "mutex_unlock" },
	{ 0xbd03ed67, "random_kmalloc_seed" },
	{ 0xbd03ed67, "__ref_stack_chk_guard" },
	{ 0xfaabfe5e, "kmalloc_caches" },
	{ 0xc064623f, "__kmalloc_cache_noprof" },
	{ 0xf46d5bf3, "mutex_lock" },
	{ 0xd710adbf, "__kmalloc_noprof" },
	{ 0xf7064e45, "usb_bulk_msg" },
	{ 0x546c19d9, "validate_usercopy_range" },
	{ 0xa61fd7aa, "__check_object_size" },
	{ 0x092a35a2, "_copy_to_user" },
	{ 0xcb8b6ec6, "kfree" },
	{ 0xd272d446, "__stack_chk_fail" },
	{ 0x8c18c8e2, "usb_submit_urb" },
	{ 0x9b1de7cb, "_dev_err" },
	{ 0x90a48d82, "__ubsan_handle_out_of_bounds" },
	{ 0xde338d9a, "_raw_spin_lock" },
	{ 0xbebe66ff, "module_layout" },
};

static const u32 ____version_ext_crcs[]
__used __section("__version_ext_crcs") = {
	0xde338d9a,
	0xc3f320b4,
	0x4073d0de,
	0xe8213e80,
	0xadb55ac9,
	0xf2f79e52,
	0xe54e0a6b,
	0xa53f4e29,
	0xe1e1f979,
	0x562e3aaa,
	0x81a1a811,
	0x16ab4215,
	0xa6c3b74d,
	0xbe011736,
	0x9d33f583,
	0xa8f96c6e,
	0x12694399,
	0xde338d9a,
	0xde338d9a,
	0x3fdc3369,
	0x092a35a2,
	0x0c8e9a2d,
	0x37688b23,
	0x95c7e581,
	0x0c8e9a2d,
	0x1094eaab,
	0x0c8e9a2d,
	0x8dc67ef7,
	0xe4de56b4,
	0x9d783e76,
	0xf76bbc40,
	0x2520ea93,
	0x7851be11,
	0x6c00f410,
	0x7851be11,
	0xd272d446,
	0x208da9f5,
	0xd272d446,
	0xd1ea1c88,
	0x7851be11,
	0x7a5ffe84,
	0x0db8d68d,
	0x6ac784f4,
	0xc87f4bab,
	0xa31fd687,
	0x283bce08,
	0x5403c125,
	0x37602407,
	0xc1e6c71e,
	0x3d212d3d,
	0xb3d1d601,
	0x9b1de7cb,
	0x887666e1,
	0xd272d446,
	0xd272d446,
	0xf46d5bf3,
	0xbd03ed67,
	0xbd03ed67,
	0xfaabfe5e,
	0xc064623f,
	0xf46d5bf3,
	0xd710adbf,
	0xf7064e45,
	0x546c19d9,
	0xa61fd7aa,
	0x092a35a2,
	0xcb8b6ec6,
	0xd272d446,
	0x8c18c8e2,
	0x9b1de7cb,
	0x90a48d82,
	0xde338d9a,
	0xbebe66ff,
};
static const char ____version_ext_names[]
__used __section("__version_ext_names") =
	"_raw_spin_unlock\0"
	"usb_free_coherent\0"
	"up\0"
	"_printk\0"
	"usb_register_driver\0"
	"fasync_helper\0"
	"__fortify_panic\0"
	"memcpy\0"
	"_raw_spin_lock_irqsave\0"
	"__kfifo_in\0"
	"_raw_spin_unlock_irqrestore\0"
	"__wake_up\0"
	"ktime_get_mono_fast_ns\0"
	"__dynamic_dev_dbg\0"
	"kill_fasync\0"
	"usb_deregister\0"
	"down_interruptible\0"
	"_raw_spin_lock_irq\0"
	"_raw_spin_unlock_irq\0"
	"usb_alloc_urb\0"
	"_copy_from_user\0"
	"usb_free_urb\0"
	"usb_alloc_coherent\0"
	"usb_anchor_urb\0"
	"usb_unanchor_urb\0"
	"usb_wait_anchor_empty_timeout\0"
	"usb_kill_urb\0"
	"usb_kill_anchored_urbs\0"
	"__ubsan_handle_load_invalid_value\0"
	"usb_find_interface\0"
	"usb_autopm_get_interface\0"
	"refcount_warn_saturate\0"
	"__get_user_1\0"
	"usb_control_msg\0"
	"__get_user_4\0"
	"__put_user_4\0"
	"usb_autopm_put_interface\0"
	"__put_user_1\0"
	"__kfifo_out\0"
	"__SCT__might_resched\0"
	"init_wait_entry\0"
	"prepare_to_wait_event\0"
	"schedule_timeout\0"
	"finish_wait\0"
	"usb_put_dev\0"
	"__kfifo_free\0"
	"__init_waitqueue_head\0"
	"usb_get_dev\0"
	"__mutex_init\0"
	"usb_register_dev\0"
	"__kfifo_alloc\0"
	"_dev_info\0"
	"usb_deregister_dev\0"
	"__fentry__\0"
	"__x86_return_thunk\0"
	"mutex_unlock\0"
	"random_kmalloc_seed\0"
	"__ref_stack_chk_guard\0"
	"kmalloc_caches\0"
	"__kmalloc_cache_noprof\0"
	"mutex_lock\0"
	"__kmalloc_noprof\0"
	"usb_bulk_msg\0"
	"validate_usercopy_range\0"
	"__check_object_size\0"
	"_copy_to_user\0"
	"kfree\0"
	"__stack_chk_fail\0"
	"usb_submit_urb\0"
	"_dev_err\0"
	"__ubsan_handle_out_of_bounds\0"
	"_raw_spin_lock\0"
	"module_layout\0"
;

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v1A86p5512d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1A86p55DBd*dc*dsc*dp*ic*isc*ip*in02*");
MODULE_ALIAS("usb:v1A86p55DDd*dc*dsc*dp*ic*isc*ip*in02*");
MODULE_ALIAS("usb:v1A86p55DEd*dc*dsc*dp*ic*isc*ip*in04*");

MODULE_INFO(srcversion, "6E598B56DF35254AF5B2802");
