savedcmd_modules.order := {   echo ch34x_pis.o; :; } > modules.order
